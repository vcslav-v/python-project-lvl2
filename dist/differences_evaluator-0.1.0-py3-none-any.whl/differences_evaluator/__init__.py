"""Differences evaluator."""
