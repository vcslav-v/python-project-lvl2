"""Differences evaluator."""
from .evaluator import generate_diff  # noqa: F401
